-- NovaInvest Supabase Database Setup - FIXED VERSION
-- Run this to reset and recreate all tables

-- ============================================
-- DROP EXISTING TABLES (to start fresh)
-- ============================================

drop table if exists public.pending_deposits cascade;
drop table if exists public.investments cascade;
drop table if exists public.transactions cascade;
drop table if exists public.profiles cascade;
drop function if exists public.handle_new_user() cascade;
drop trigger if exists on_auth_user_created on auth.users;

-- ============================================
-- 1. PROFILES TABLE (extends auth.users)
-- ============================================
-- NOTE: btc_address is NOT unique since all users share the same deposit address

create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text unique not null,
  name text not null,
  balance numeric default 0,
  btc_address text not null default 'bc1q5pz4qu88340fquj6lvhhw9fchu7z88g2cqqdl6',
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS on profiles
alter table public.profiles enable row level security;

-- Profiles policies
create policy "Users can view own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- ============================================
-- 2. TRANSACTIONS TABLE
-- ============================================

create table public.transactions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  type text not null check (type in ('deposit', 'withdrawal', 'investment', 'return')),
  amount numeric not null,
  status text not null default 'pending' check (status in ('pending', 'completed', 'failed')),
  description text,
  btc_address text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS on transactions
alter table public.transactions enable row level security;

-- Transactions policies
create policy "Users can view own transactions"
  on public.transactions for select
  using (auth.uid() = user_id);

create policy "Users can insert own transactions"
  on public.transactions for insert
  with check (auth.uid() = user_id);

create policy "Users can update own transactions"
  on public.transactions for update
  using (auth.uid() = user_id);

-- ============================================
-- 3. INVESTMENTS TABLE
-- ============================================

create table public.investments (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  commodity_id text not null,
  commodity_name text not null,
  amount numeric not null,
  quantity numeric not null,
  purchase_price numeric not null,
  current_value numeric not null,
  profit numeric default 0,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS on investments
alter table public.investments enable row level security;

-- Investments policies
create policy "Users can view own investments"
  on public.investments for select
  using (auth.uid() = user_id);

create policy "Users can insert own investments"
  on public.investments for insert
  with check (auth.uid() = user_id);

create policy "Users can update own investments"
  on public.investments for update
  using (auth.uid() = user_id);

create policy "Users can delete own investments"
  on public.investments for delete
  using (auth.uid() = user_id);

-- ============================================
-- 4. PENDING DEPOSITS TABLE
-- ============================================

create table public.pending_deposits (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  amount numeric not null,
  status text not null default 'pending' check (status in ('pending', 'completed')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS on pending deposits
alter table public.pending_deposits enable row level security;

-- Pending deposits policies
create policy "Users can view own pending deposits"
  on public.pending_deposits for select
  using (auth.uid() = user_id);

create policy "Users can insert own pending deposits"
  on public.pending_deposits for insert
  with check (auth.uid() = user_id);

create policy "Users can update own pending deposits"
  on public.pending_deposits for update
  using (auth.uid() = user_id);

-- ============================================
-- 5. AUTO-CREATE PROFILE ON SIGNUP
-- ============================================

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'name', 'User')
  );
  return new;
exception
  when others then
    -- Log the error and re-raise
    raise notice 'Error creating profile: %', SQLERRM;
    return new;
end;
$$ language plpgsql security definer;

-- Trigger to create profile on signup
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================
-- 6. ENABLE REALTIME (for live updates)
-- ============================================

-- Enable realtime for all tables
alter publication supabase_realtime add table public.profiles;
alter publication supabase_realtime add table public.transactions;
alter publication supabase_realtime add table public.investments;
alter publication supabase_realtime add table public.pending_deposits;

-- ============================================
-- DONE! Your database is ready.
-- All new users will get BTC address: bc1q5pz4qu88340fquj6lvhhw9fchu7z88g2cqqdl6
-- ============================================
