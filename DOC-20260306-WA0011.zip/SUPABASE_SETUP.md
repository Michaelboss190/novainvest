# NovaInvest Supabase Setup Guide

## Step 1: Create Supabase Account & Project

1. Go to https://supabase.com
2. Click "Start your project" and sign up with your email/GitHub
3. Create a new organization (e.g., "NovaInvest")
4. Create a new project:
   - Name: `novainvest`
   - Database Password: (create a strong password, save it!)
   - Region: Choose closest to your users
5. Wait for the project to be created (takes 1-2 minutes)

## Step 2: Get Your API Keys

Once your project is ready:

1. Click the Settings icon (gear) in the left sidebar
2. Go to "API" section
3. Copy these values:
   - **Project URL** (e.g., `https://xxxxxxxxxxxx.supabase.co`)
   - **anon public** API key (starts with `eyJ...`)

## Step 3: Create Database Tables

1. In Supabase dashboard, click "SQL Editor" in the left sidebar
2. Click "New query"
3. Copy and paste the SQL below, then click "Run"

```sql
-- Enable Row Level Security
alter table auth.users enable row level security;

-- Users table (extends auth.users)
create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text unique not null,
  name text not null,
  balance numeric default 0,
  btc_address text unique not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS on profiles
alter table public.profiles enable row level security;

-- Profiles policies
create policy "Users can view own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- Transactions table
create table public.transactions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  type text not null check (type in ('deposit', 'withdrawal', 'investment', 'return')),
  amount numeric not null,
  status text not null default 'pending' check (status in ('pending', 'completed', 'failed')),
  description text,
  btc_address text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS on transactions
alter table public.transactions enable row level security;

-- Transactions policies
create policy "Users can view own transactions"
  on public.transactions for select
  using (auth.uid() = user_id);

create policy "Users can insert own transactions"
  on public.transactions for insert
  with check (auth.uid() = user_id);

create policy "Users can update own transactions"
  on public.transactions for update
  using (auth.uid() = user_id);

-- Investments table
create table public.investments (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  commodity_id text not null,
  commodity_name text not null,
  amount numeric not null,
  quantity numeric not null,
  purchase_price numeric not null,
  current_value numeric not null,
  profit numeric default 0,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS on investments
alter table public.investments enable row level security;

-- Investments policies
create policy "Users can view own investments"
  on public.investments for select
  using (auth.uid() = user_id);

create policy "Users can insert own investments"
  on public.investments for insert
  with check (auth.uid() = user_id);

create policy "Users can update own investments"
  on public.investments for update
  using (auth.uid() = user_id);

create policy "Users can delete own investments"
  on public.investments for delete
  using (auth.uid() = user_id);

-- Pending deposits table
create table public.pending_deposits (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  amount numeric not null,
  status text not null default 'pending' check (status in ('pending', 'completed')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS on pending deposits
alter table public.pending_deposits enable row level security;

-- Pending deposits policies
create policy "Users can view own pending deposits"
  on public.pending_deposits for select
  using (auth.uid() = user_id);

create policy "Users can insert own pending deposits"
  on public.pending_deposits for insert
  with check (auth.uid() = user_id);

create policy "Users can update own pending deposits"
  on public.pending_deposits for update
  using (auth.uid() = user_id);

-- Create function to handle new user signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, name, btc_address)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'name', 'User'),
    'bc1q' || encode(gen_random_bytes(19), 'hex')
  );
  return new;
end;
$$ language plpgsql security definer;

-- Trigger to create profile on signup
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Create demo users (optional)
-- Run this after setting up the auth users in Supabase Auth
```

## Step 4: Create Demo Users (Optional)

If you want demo users with starting balances:

1. Go to "Authentication" → "Users" in the sidebar
2. Click "Add user" → "Create new user"
3. Create these users:

**Demo User 1:**
- Email: `demo@novainvest.com`
- Password: `demo123`
- User Metadata: `{"name": "Demo User"}`

**Demo User 2:**
- Email: `investor@example.com`
- Password: `investor123`
- User Metadata: `{"name": "John Investor"}`

4. Then run this SQL to add balances:

```sql
-- Update demo user balances
update public.profiles set balance = 50000 where email = 'demo@novainvest.com';
update public.profiles set balance = 125000 where email = 'investor@example.com';

-- Add sample transactions for demo users
insert into public.transactions (user_id, type, amount, status, description)
select id, 'deposit', 50000, 'completed', 'Initial deposit'
from public.profiles where email = 'demo@novainvest.com';

insert into public.transactions (user_id, type, amount, status, description)
select id, 'deposit', 125000, 'completed', 'Initial deposit'
from public.profiles where email = 'investor@example.com';
```

## Step 5: Update Your App

After getting your Supabase credentials, update the `.env` file in your project:

```
VITE_SUPABASE_URL=https://your-project-url.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

Then rebuild and deploy!

## Step 6: Enable Email Confirmations (Optional)

If you want users to confirm their email:

1. Go to "Authentication" → "Providers"
2. Click "Email" 
3. Toggle "Confirm email" ON or OFF as needed
4. Save changes

## Free Tier Limits

Supabase free tier includes:
- 500MB database storage
- 2GB bandwidth/month
- 50,000 users/month
- Unlimited API requests

Perfect for getting started!
